#!/usr/bin/env bash
# Runs once when the Codespace is created.
set -euo pipefail

echo "==> Installing Python packages"
python -m pip install --upgrade pip --quiet
python -m pip install -r requirements.txt --quiet

echo "==> Fetching the Apache Ossie spec and examples (read-only reference)"
REF_DIR="/workspaces/ossie-reference"
if [ ! -d "$REF_DIR" ]; then
  git clone --depth 1 https://github.com/apache/ossie.git "$REF_DIR" || \
    echo "    Could not clone apache/ossie; you can retry later with: git clone https://github.com/apache/ossie.git $REF_DIR"
fi

echo "==> Done. Next: run  bash scripts/check_setup.sh"
